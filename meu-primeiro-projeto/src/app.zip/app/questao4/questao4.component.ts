import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-questao4',
  templateUrl: './questao4.component.html',
  styleUrls: ['./questao4.component.css']
})
export class Questao4Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
