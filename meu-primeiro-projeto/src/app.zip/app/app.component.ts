
import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {

































  
  // nome = 'Erisson';
  // pais = 'BR';

  // pessoas: any[] = [
  //   {nome: 'erisson', pais: 'BR'},
  //   {nome: 'carol', pais: 'CNH'},
  //   {nome: 'ruan', pais: 'US'},
  //   {nome: 'nat', pais: 'UK'},
  //   {nome: 'andre', pais: 'CE'},
  //   {nome: 'juh', pais: 'CE'}
  // ];


  // alunos: any[] = [
  //   {nome: 'erisson', media: '7.5'},
  //   {nome: 'erisson 2', media: '5.5'},
  //   {nome: 'erisson 3', media: '2.3'},
  // ];

  // getCorM(media) {
  //   switch (media){
  //     case media > 7:
  //       return 'green';
  //     case media < 7:
  //       return 'ded';
  //     return 'yelow';
  //   }
  // }


  // getCor(pais) {
  //   switch (pais) {
  //     case'BR':
  //       return'red';
  //     case'UK':
  //       return'green';
  //     case'US':
  //       return'blue';
  //     case'CHN':
  //       return'pink';
  //     case'CE':
  //       return'orange';
  //   }
  // }



  // pessoas = [];

  // salvarPessoa(pessoa: any) {
  //   this.pessoas.push(pessoa);
  // }
}























// import { Component } from '@angular/core';

// @Component({
//   selector: 'app-root',
//   templateUrl: './app.component.html',
//   styleUrls: ['./app.component.css']
// })

// export class AppComponent {
//   nome = 'Jefferson de Carvalho';

//   salvar(nomeInput: string) {
//     this.nome = nomeInput;
//   }

//   mudar(event: any) {
//     this.nome = event.target.value;
//   }

//   mostrarData(data: Object) {
//     console.log('Ano:' + data['year']);
//     console.log('Mês:' + data['month']);
//     console.log('Dia:' + data['day']);
//   }

// }



















// import { Component, Input } from '@angular/core';

// @Component({
//   selector: 'app-root',
//   templateUrl: './app.component.html',
//   styleUrls: ['./app.component.css']
// })
// export class AppComponent {
//   nome = 'Betinna';
//   idade = 22;
//   saldo = 1042000;



//   salvar(nomeInput:any) {
//     this.nome = nomeInput;
//     this.nome = 'Betinnnna ' + this.idade;
//     this.idade++;
//    }

//   mudar(evento:any) {
//     this.nome = evento.target.value;
//   }

// }
