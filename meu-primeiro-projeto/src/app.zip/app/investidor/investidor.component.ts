import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-investidor',
  templateUrl: './investidor.component.html',
  styleUrls: ['./investidor.component.css']
})
export class InvestidorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
