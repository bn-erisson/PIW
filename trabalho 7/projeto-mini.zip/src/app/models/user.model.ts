export class User{
    //id:number;
    _id:any;
    login:string;
    firstName:string;
    lastName:string;
    email:string;
    zipcode:string;
    password:string;
}