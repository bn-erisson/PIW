export class Product{
    // id:number;
    _id:any;
    name:string;
    price:number;
    qty:number;
}